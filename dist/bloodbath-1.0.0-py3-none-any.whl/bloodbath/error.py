class ApiKeyError(Exception):
  pass