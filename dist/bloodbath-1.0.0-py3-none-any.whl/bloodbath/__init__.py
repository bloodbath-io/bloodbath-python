# Bloodbath Python bindings
# Author:
# Laurent Schaffner <laurent.schaffner.code@gmail.com>

# Configuration variables

api_key = None
api_url = 'https://api.bloodbath.io/rest'

# Event
from bloodbath.event import *